# CC Switch 详细配置指南

## CC Switch 简介

CC Switch 是一个跨平台桌面应用，用于管理 Claude Code、Codex、Gemini CLI 等 AI 编程工具的 Provider 配置。

### 核心功能
- **Provider 管理**: 一键添加、切换 Provider
- **应用路由**: 路由 API 请求，支持协议转换
- **MCP 管理**: 统一管理 MCP 服务器
- **使用统计**: 跟踪花费、请求数、token 用量

---

## 安装 CC Switch

**官方下载地址**: https://github.com/farion1231/cc-switch/releases

### Windows
1. 从 GitHub 下载 `CC-Switch-v3.16.2-Windows.msi`
2. 双击安装
3. 启动 CC Switch

### macOS
```bash
# 方式一：Homebrew（推荐）
brew install --cask cc-switch

# 方式二：下载 DMG
# 从 GitHub 下载 CC-Switch-v3.16.2-macOS.dmg
# 双击安装
```

---

## 配置 DeepSeek Provider

### 步骤 1：打开 CC Switch

启动 CC Switch 后，你会看到主界面。

![CC Switch 主界面](../images/ccswitch-main.png)

### 步骤 2：添加 DeepSeek Provider

1. 点击 **"添加供应商"** 按钮
2. 选择 **"Codex"** 作为工具类型
3. 在供应商列表里找到 **"DeepSeek"**（如果有预设就直接选）
4. 如果没有 DeepSeek 预设，选 **"自定义"**

![添加供应商界面](../images/ccswitch-add.png)

### 步骤 3：填写配置信息

| 字段 | 值 | 说明 |
|------|-----|------|
| 名称 | `DeepSeek` | Provider 名称（随便起） |
| Base URL | `https://api.deepseek.com` | DeepSeek API 地址 |
| API Key | `sk-你的密钥` | DeepSeek API Key |
| Model | `deepseek-chat` | 模型名称 |

### 步骤 4：启用 Provider

1. 选择刚创建的 Provider
2. 点击 **"启用"** 按钮
3. 看到绿色对勾就成功了

---

## 开启 Codex 路由（重要！）

**这是让 DeepSeek 正常工作的关键步骤！**

### 为什么需要开启路由？

Codex 使用 OpenAI Responses API，而 DeepSeek 使用 Chat Completions API。开启路由后，CC Switch 会自动处理协议转换。

### 开启步骤

1. 打开 CC Switch 设置
2. 找到 **高级** → **路由服务**
3. 找到 **应用路由** 区域
4. 开启 **Codex 路由** 开关

开启后，CC Switch 会：
- 自动修改 Codex 配置，将 API 端点指向本地路由
- 路由收到请求后，自动转发到 DeepSeek
- 自动处理协议转换

### 路由状态指示

开启路由后：
- **路由 Logo 颜色**：从无色变为绿色
- **供应商卡片**：当前活跃的供应商显示绿色边框

---

## 系统托盘快速切换

CC Switch 支持系统托盘快速切换 Provider：

1. 点击系统托盘中的 CC Switch 图标
2. 选择要使用的 Provider
3. 即时生效（无需重启 Codex）

---

## 配置文件位置

| 文件 | 路径 | 说明 |
|------|------|------|
| 数据库 | `~/.cc-switch/cc-switch.db` | Provider、MCP 等数据 |
| 设置 | `~/.cc-switch/settings.json` | 设备级 UI 偏好 |
| 备份 | `~/.cc-switch/backups/` | 自动备份 |

---

## 常见配置问题

### Q: 切换 Provider 后 Codex 没有生效

**解决方案**: 
- 如果开启了路由，切换即时生效，无需重启
- 如果没开启路由，需要重启 Codex

### Q: 提示 API Key 无效

**解决方案**:
- 检查 DeepSeek API Key 是否正确（以 `sk-` 开头）
- 确认 DeepSeek 账户有余额
- 检查网络连接

### Q: CC Switch 里没有 DeepSeek 预设

**解决方案**: 选 **自定义**，手动填写 Base URL 和 API Key

### Q: 路由后请求失败

**解决方案**:
- 检查路由服务是否正常运行
- 检查供应商配置是否正确
- 检查网络是否正常

---

## 高级配置

### 云同步

CC Switch 支持通过 Dropbox、OneDrive、iCloud 或 WebDAV 同步配置：

1. 打开设置
2. 找到 **"云同步"** 选项
3. 选择同步服务
4. 配置同步目录

### Deep Link

CC Switch 支持 `ccswitch://` 协议导入配置：

```
ccswitch://import-provider?url=...
```

---

## 下一步

配置完成后，请继续阅读：
- [DeepSeek API 申请](../02-配置教程/01-DeepSeek-API申请.md)
- [Codex 桌面版配置](../02-配置教程/02-Codex桌面版配置.md)
- [完整配置流程](../02-配置教程/03-完整配置流程.md)
