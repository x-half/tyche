@echo off
chcp 65001 >nul
echo =====================================
echo   Codex + DeepSeek 一键配置脚本
echo =====================================
echo.

echo [1/4] 检查 Codex CLI...
codex --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Codex CLI 未安装，正在安装...
    powershell -ExecutionPolicy ByPass -c "irm https://chatgpt.com/codex/install.ps1 | iex"
    if %errorlevel% neq 0 (
        echo 安装失败，请手动安装
        pause
        exit /b 1
    )
)
echo Codex CLI 已安装

echo.
echo [2/4] 检查 CC Switch...
where cc-switch >nul 2>&1
if %errorlevel% neq 0 (
    echo CC Switch 未安装
    echo 请从以下地址下载安装：
    echo https://github.com/farion1231/cc-switch/releases
    echo.
    pause
    exit /b 1
)
echo CC Switch 已安装

echo.
echo [3/4] 配置 DeepSeek API...
echo.
echo 请访问 https://platform.deepseek.com 获取 API Key
echo.
set /p API_KEY="请输入你的 DeepSeek API Key (sk-xxx): "

if "%API_KEY%"=="" (
    echo API Key 不能为空
    pause
    exit /b 1
)

echo.
echo [4/4] 生成配置文件...
echo.

:: 创建 Codex 配置目录
if not exist "%USERPROFILE%\.codex" mkdir "%USERPROFILE%\.codex"

:: 写入配置
(
echo model_provider = "custom"
echo model = "deepseek-chat"
echo model_reasoning_effort = "high"
echo.
echo [model_providers.custom]
echo name = "codex-deepseek"
echo base_url = "http://127.0.0.1:11435"
echo wire_api = "responses"
echo requires_openai_auth = true
) > "%USERPROFILE%\.codex\config.toml"

:: 写入认证信息
echo {"api_key": "sk-placeholder"} > "%USERPROFILE%\.codex\auth.json"

echo 配置文件已生成
echo.
echo =====================================
echo   配置完成!
echo =====================================
echo.
echo 下一步:
echo 1. 打开 CC Switch
echo 2. 配置 DeepSeek API 信息
echo 3. 启用 Provider
echo 4. 运行 codex app 启动桌面版
echo.
echo 如需帮助，请查看资料包中的教程
echo.
pause
