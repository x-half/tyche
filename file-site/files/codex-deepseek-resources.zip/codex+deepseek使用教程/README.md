# Codex 桌面版 + DeepSeek 配置资料包

> **版本**: v2.0 | **更新日期**: 2026年6月10日

---

## 核心方案说明

本资料包介绍如何使用 **DeepSeek** 作为 **Codex 桌面版** 的后端模型。

### 为什么需要 CC Switch？

Codex 桌面版使用 **OpenAI Responses API**，而 DeepSeek 提供的是 **Chat Completions API**。两者协议不同，无法直接对接。

**CC Switch** 是一个桌面管理工具，内置了协议转换代理，可以让 Codex 无缝使用 DeepSeek。

### 完整调用链路

```
Codex 桌面版 → CC Switch → 协议转换代理 → DeepSeek API
```

---

## 资料包目录

```
Codex+DeepSeek资料包/
├── README.md                      # 本文件
├── 01-所需软件/
│   ├── 下载链接.md                # 所有软件下载地址
│   └── CC-Switch配置.md           # CC Switch 详细配置
├── 02-配置教程/
│   ├── 01-DeepSeek-API申请.md     # API Key 申请
│   ├── 02-Codex桌面版配置.md      # Codex 桌面版配置
│   └── 03-完整配置流程.md         # 从零到一完整流程
├── 03-使用教程/
│   ├── 01-基础使用.md             # Codex 基础操作
│   └── 02-实战案例.md             # 真实编程场景
├── 04-常见问题/
│   └── FAQ.md                     # 常见问题解答
└── 05-脚本工具/
    └── 一键配置.bat               # Windows 一键配置
```

---

## 快速开始（10分钟搞定）

### 第一步：下载安装软件

1. **CC Switch**: https://github.com/farion1231/cc-switch/releases
2. **Codex 桌面版**: 运行 `codex app` 或访问 https://chatgpt.com/codex

### 第二步：申请 DeepSeek API Key

1. 访问 https://platform.deepseek.com
2. 注册并登录
3. 创建 API Key
4. 充值余额（建议先充 10 元）

### 第三步：配置 CC Switch

1. 打开 CC Switch
2. 添加 Codex Provider
3. 配置 DeepSeek API 信息
4. 启用配置

### 第四步：启动 Codex 桌面版

1. 重启 Codex 桌面版
2. 开始使用

---

## 详细教程

请按照以下顺序阅读：

1. [下载链接](./01-所需软件/下载链接.md) - 获取所有需要的软件
2. [DeepSeek API 申请](./02-配置教程/01-DeepSeek-API申请.md) - 申请 API Key
3. [完整配置流程](./02-配置教程/03-完整配置流程.md) - 从零配置
4. [基础使用](./03-使用教程/01-基础使用.md) - 学习基本操作
5. [常见问题](./04-常见问题/FAQ.md) - 遇到问题查看

---

## 系统要求

| 系统 | 最低版本 |
|------|---------|
| Windows | Windows 10+ |
| macOS | macOS 12+ |
| Linux | Ubuntu 22.04+ / Debian 11+ |

---

## 费用说明

- **CC Switch**: 免费开源
- **Codex 桌面版**: 免费（需要 OpenAI 账号或 API Key）
- **DeepSeek API**: 按 token 计费，约 ¥1-8/百万 token

日常使用约 ¥5-50/月。

---

## 技术支持

- CC Switch: https://github.com/farion1231/cc-switch
- Codex: https://github.com/openai/codex
- DeepSeek: https://platform.deepseek.com
