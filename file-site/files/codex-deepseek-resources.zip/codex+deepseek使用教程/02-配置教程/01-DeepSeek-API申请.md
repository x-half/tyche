# DeepSeek API Key 申请教程

## 什么是 DeepSeek？

DeepSeek 是国内顶尖的 AI 大模型公司，提供与 OpenAI 兼容的 API 接口。价格便宜，国内直连，无需翻墙。

---

## 申请步骤

### 第一步：注册账号

1. 打开浏览器，访问 https://platform.deepseek.com
2. 点击右上角 **"注册"**
3. 选择注册方式：
   - **手机号**（推荐，支持 +86）
   - 邮箱
   - 微信扫码
4. 完成注册

### 第二步：登录控制台

使用注册的账号登录，进入 DeepSeek Platform 控制台。

### 第三步：创建 API Key

1. 在左侧菜单找到 **"API Keys"**
2. 点击 **"创建 API Key"**
3. 输入名称（如 `codex-key`）
4. 点击创建
5. **立即复制保存**（只显示一次）

### 第四步：充值余额

1. 在左侧菜单找到 **"费用"** 或 **"充值"**
2. 选择金额（建议先充 10-50 元）
3. 支持支付宝、微信支付
4. 完成充值

---

## API Key 格式

```
sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

- 以 `sk-` 开头
- 约 50+ 个字符

---

## API 连接信息

| 参数 | 值 |
|------|-----|
| Base URL | `https://api.deepseek.com` |
| API Key | `sk-你的密钥` |
| 模型 | `deepseek-chat` |

---

## 价格参考

| 模型 | 输入 | 输出 |
|------|------|------|
| deepseek-chat | ¥1/百万token | ¥2/百万token |
| deepseek-reasoner | ¥2/百万token | ¥8/百万token |

**月费估算**: 日常使用约 ¥5-50/月

---

## 验证 API Key

测试命令：

```bash
curl https://api.deepseek.com/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-你的密钥" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"Hello"}]}'
```

返回正常 JSON 响应即可。

---

## 安全注意事项

1. 不要泄露 API Key
2. 不要上传到公开仓库
3. 建议设置消费限额
4. 定期检查用量

---

## 下一步

- [Codex 桌面版配置](./02-Codex桌面版配置.md)
- [完整配置流程](./03-完整配置流程.md)
