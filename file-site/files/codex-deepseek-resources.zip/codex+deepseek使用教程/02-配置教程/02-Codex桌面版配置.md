# Codex 桌面版配置教程

## Codex 桌面版简介

Codex 桌面版是 OpenAI 的 AI 编程助手 GUI 版本，提供可视化的编程体验。

---

## 获取 Codex 桌面版

### 方式一：通过 CLI 启动（推荐）

1. **安装 Codex CLI**

Windows:
```powershell
powershell -ExecutionPolicy ByPass -c "irm https://chatgpt.com/codex/install.ps1 | iex"
```

Mac/Linux:
```bash
curl -fsSL https://chatgpt.com/codex/install.sh | sh
```

2. **启动桌面版**
```bash
codex app
```

### 方式二：网页版

访问 https://chatgpt.com/codex

---

## 首次启动配置

### 1. 登录 OpenAI 账号

首次启动需要登录 OpenAI 账号：
- 选择 **"Sign in with ChatGPT"**
- 或使用 API Key

### 2. 配置 Provider（使用 DeepSeek）

要使用 DeepSeek，需要通过 CC Switch 配置 Provider：

1. 打开 CC Switch
2. 添加 Codex Provider
3. 配置 DeepSeek 信息
4. 启用 Provider
5. 重启 Codex 桌面版

---

## Codex 桌面版功能

### 主要功能

- **代码生成**: 自然语言描述生成代码
- **代码解释**: 选中代码，按快捷键解释
- **代码重构**: 优化现有代码
- **Bug 修复**: 自动检测和修复问题
- **测试生成**: 自动生成单元测试

### 界面说明

- **对话区**: 与 AI 对话
- **代码区**: 查看和编辑代码
- **文件浏览器**: 项目文件管理
- **终端**: 内置终端

---

## 常用操作

### 创建项目

```
创建一个 React + TypeScript 项目，使用 Vite 构建
```

### 修改代码

```
请为这个函数添加错误处理
```

### 生成测试

```
请为这个模块编写单元测试
```

### 代码审查

```
请审查这段代码，指出潜在问题
```

---

## 快捷键

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+Enter` | 发送消息 |
| `Ctrl+Shift+P` | 命令面板 |
| `Ctrl+`` ` `` | 打开终端 |
| `Ctrl+B` | 切换侧边栏 |

---

## 工作目录

Codex 会读取当前项目的文件作为上下文：

1. 打开 Codex 桌面版
2. 选择 **"打开文件夹"**
3. 选择你的项目目录
4. Codex 会自动读取项目结构

---

## 常见问题

### Q: Codex 桌面版无法启动

**解决方案**:
- 确认已安装 Codex CLI
- 检查是否登录 OpenAI 账号
- 尝试重新安装

### Q: 无法连接 DeepSeek

**解决方案**:
- 确认 CC Switch 已配置并启用
- 检查 DeepSeek API Key 是否有效
- 重启 Codex 桌面版

### Q: 响应速度慢

**解决方案**:
- 检查网络连接
- 尝试切换模型
- 减少上下文代码量

---

## 下一步

- [完整配置流程](./03-完整配置流程.md)
- [基础使用教程](../03-使用教程/01-基础使用.md)
