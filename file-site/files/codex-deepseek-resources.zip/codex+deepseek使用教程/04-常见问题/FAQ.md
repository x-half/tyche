# 常见问题解答 (FAQ)

## 重要提示

**使用 Codex 需要科学上网工具！**

因为 Codex 是 OpenAI 的产品，首次登录和启动时需要连接 OpenAI 服务器。如果没有科学上网，Codex 可能无法正常启动或登录。

**DeepSeek 不需要科学上网**，国内直连即可。

---

## 安装问题

### Q1: CC Switch 下载很慢

**解决方案**:
- 使用科学上网
- 使用国内镜像（见官方文档）
- 使用便携版（Portable）

### Q2: Codex 桌面版安装失败

**解决方案**:
- 检查网络连接
- 以管理员身份运行安装程序
- 关闭杀毒软件后重试

### Q3: Codex 桌面版无法启动

**解决方案**:
- **确认已开启科学上网**
- 重新安装 Codex 桌面版
- 检查是否满足系统要求
- 重启电脑后重试

---

## 配置问题

### Q4: CC Switch 中看不到 Codex 选项

**解决方案**:
- 更新 CC Switch 到最新版本
- 确认已安装 Codex 桌面版

### Q5: 添加 Provider 后无法启用

**解决方案**:
- 检查配置信息是否正确
- 确认 API Key 有效
- 重启 CC Switch

### Q6: DeepSeek API Key 无效

**解决方案**:
- 检查 Key 是否复制完整
- 确认 Key 以 `sk-` 开头
- 检查 DeepSeek 账户是否有余额

### Q7: CC Switch 里没有 DeepSeek 预设

**解决方案**: 点击 **新建**，手动填写 Base URL 和 API Key

---

## 使用问题

### Q8: Codex 连接 DeepSeek 失败

**解决方案**:
1. **确认已开启科学上网**
2. 确认 CC Switch 已启动
3. 确认 DeepSeek Provider 已启用
4. **确认 Codex 路由已开启**
5. 检查 API Key 是否正确
6. 重启 Codex 桌面版

### Q9: 响应速度很慢

**解决方案**:
- 检查网络延迟
- DeepSeek 高峰期可能稍慢，等一会儿再试
- 尝试切换模型

### Q10: 生成的代码有错误

**解决方案**:
- 提供更具体的需求
- 分步生成，每步验证
- 追问让 Codex 修复

### Q11: 科学上网工具怎么选？

**建议**:
- 选择稳定的付费工具
- 确保可以访问 OpenAI（api.openai.com）
- 推荐使用美国、日本、新加坡节点

### Q12: 科学上网开了还是连不上

**解决方案**:
- 检查是否选择了正确的节点
- 确认可以访问 api.openai.com
- 尝试切换不同的代理协议
- 重启 Codex 后重试

---

## 费用问题

### Q13: DeepSeek 怎么收费？

按 token 计费：
- 输入: ¥1-2/百万 token
- 输出: ¥2-8/百万 token

日常使用约 ¥5-50/月。

### Q14: 如何查看用量

登录 https://platform.deepseek.com → "费用"页面

### Q15: 如何设置消费限额

在 DeepSeek 控制台设置月度限额。

---

## 进阶问题

### Q16: 如何切换回 OpenAI

在 CC Switch 中：
1. 添加 OpenAI Provider
2. 启用 OpenAI Provider
3. 重启 Codex

### Q17: 如何使用其他模型

在 CC Switch 中修改：
- API Base URL
- API Key
- Model 名称

### Q18: 配置文件在哪里

| 文件 | 路径 |
|------|------|
| CC Switch 数据库 | `~/.cc-switch/cc-switch.db` |
| CC Switch 设置 | `~/.cc-switch/settings.json` |

---

## 获取帮助

1. **CC Switch**: https://github.com/farion1231/cc-switch
2. **Codex**: https://github.com/openai/codex
3. **DeepSeek**: https://platform.deepseek.com
